(function(){
	var this = LUCID;

// %LIBS%
nprovide("$",function(){return{abc:123}});
provide("__",function(){return{abc:123}});

// %MODULES%

}).call(this['LUCID'] = this['LUCID'] || {});
