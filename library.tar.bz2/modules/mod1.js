provide('module1', function(){
	var LUCID = this;
	return {};
});
