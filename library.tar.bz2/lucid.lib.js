(function(){
	var this = LUCID;
	
	function provide(point, singleton) {
		LUCID[point] = singleton.call(LUCID);
	};


// %LIBS%

// %MODULES%

}).call(this['LUCID'] = this['LUCID'] || {});
