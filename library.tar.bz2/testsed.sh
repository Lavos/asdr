#!/bin/bash

TEMPLATE=$1
CONTENT="/af/adsf/sdaf/asdf/asd/fads/f/asdf/asdf/"

cat "$TEMPLATE" | sed "/%LIBS/ a\
$CONTENT" > test.js
