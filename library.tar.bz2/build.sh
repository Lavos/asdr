#!/bin/bash

TEMPLATE=$1
LIB_LINES=''
MOD_LINES=''

for lib in $(ls ./lib/*)
do
	filename=$(basename "$lib")
	extension="${filename##*.}"
	filename="${filename%.*}"

	echo "$lib"
	test=`curl \
		--data-urlencode "js_code@$lib" \
		-d compilation_level=SIMPLE_OPTIMIZATIONS \
		-d output_info=compiled_code \
		-d output_format=text \
		http://closure-compiler.appspot.com/compile`
	LIB_LINES="$LIB_LINES$test\n"
done

for mod in $(ls ./modules/*)
do
	filename=$(basename "$mod")
	extension="${filename##*.}"
	filename="${filename%.*}"

	echo "$mod"
	test=`curl \
		--data-urlencode "js_code@$mod" \
		-d compilation_level=SIMPLE_OPTIMIZATIONS \
		-d output_info=compiled_code \
		-d output_format=text \
		http://closure-compiler.appspot.com/compile`
	MOD_LINES="$MOD_LINES\n$test"
done

cat "$TEMPLATE" | sed "/%LIBS/ a\
$LIB_LINES"
